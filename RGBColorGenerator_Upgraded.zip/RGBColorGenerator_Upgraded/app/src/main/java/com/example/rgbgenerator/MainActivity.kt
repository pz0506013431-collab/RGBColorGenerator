package com.example.rgbgenerator

import android.app.Activity
import android.content.*
import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var preview: View
    private lateinit var rgbText: TextView
    private lateinit var hexText: TextView
    private lateinit var favorites: LinearLayout
    private val bars = arrayListOf<SeekBar>()
    private val nums = arrayListOf<TextView>()
    private val prefs by lazy { getSharedPreferences("rgb", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        build()
        update()
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "🎨 RGB Studio"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(20,20,20))
            setPadding(0, 8, 0, 14)
        }
        root.addView(title, LinearLayout.LayoutParams(-1,-2))

        preview = View(this)
        root.addView(preview, LinearLayout.LayoutParams(-1,250).apply { bottomMargin=16 })

        rgbText = TextView(this).apply {
            textSize=19f; gravity=Gravity.CENTER; setTextColor(Color.DKGRAY)
        }
        root.addView(rgbText)

        hexText = TextView(this).apply {
            textSize=26f; gravity=Gravity.CENTER; setTextColor(Color.BLACK)
            setPadding(0,2,0,12)
        }
        root.addView(hexText)

        val names = arrayOf("R  אדום","G  ירוק","B  כחול")
        for (i in 0..2) {
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            val label=TextView(this).apply{text=names[i];textSize=17f}
            val n=TextView(this).apply{text="127";textSize=17f;gravity=Gravity.CENTER}
            nums.add(n)
            head.addView(label,LinearLayout.LayoutParams(0,-2,1f))
            head.addView(n,LinearLayout.LayoutParams(55,-2))
            val bar=SeekBar(this).apply{
                max=255; progress=127
                setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
                    override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){ nums[i].text=p.toString(); update() }
                    override fun onStartTrackingTouch(s:SeekBar?){}
                    override fun onStopTrackingTouch(s:SeekBar?){}
                })
            }
            bars.add(bar); row.addView(head); row.addView(bar)
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=4})
        }

        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val random=Button(this).apply{
            text="🎲 אקראי"; textSize=16f
            setOnClickListener{bars.forEach{it.progress=(0..255).random()}; saveHistory(); update()}
        }
        val copy=Button(this).apply{
            text="📋 העתק HEX"; textSize=16f
            setOnClickListener{copy(hexText.text.toString())}
        }
        val fav=Button(this).apply{
            text="❤️ שמור"; textSize=16f
            setOnClickListener{saveFavorite(currentHex()); Toast.makeText(this@MainActivity,"נשמר במועדפים",Toast.LENGTH_SHORT).show()}
        }
        buttons.addView(random,LinearLayout.LayoutParams(0,56,1f))
        buttons.addView(copy,LinearLayout.LayoutParams(0,56,1f))
        buttons.addView(fav,LinearLayout.LayoutParams(0,56,1f))
        root.addView(buttons)

        val favTitle=TextView(this).apply{text="מועדפים";textSize=20f;setPadding(0,12,0,5)}
        root.addView(favTitle)
        favorites=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(favorites,LinearLayout.LayoutParams(-1,0,1f))
        loadFavorites()

        setContentView(root)
    }

    private fun currentHex():String {
        val r=bars[0].progress; val g=bars[1].progress; val b=bars[2].progress
        return String.format(Locale.US,"#%02X%02X%02X",r,g,b)
    }

    private fun update(){
        val r=bars[0].progress; val g=bars[1].progress; val b=bars[2].progress
        preview.setBackgroundColor(Color.rgb(r,g,b))
        rgbText.text="RGB($r, $g, $b)"
        hexText.text=currentHex()
    }

    private fun copy(s:String){
        val cm=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("HEX",s))
        Toast.makeText(this,"הועתק: $s",Toast.LENGTH_SHORT).show()
    }

    private fun saveFavorite(hex:String){
        val old=prefs.getStringSet("favorites",emptySet())!!.toMutableSet()
        old.add(hex)
        prefs.edit().putStringSet("favorites",old).apply()
        loadFavorites()
    }

    private fun saveHistory(){
        val old=prefs.getStringSet("history",emptySet())!!.toMutableSet()
        old.add(currentHex())
        prefs.edit().putStringSet("history",old.takeLast(12).toSet()).apply()
    }

    private fun loadFavorites(){
        if (!::favorites.isInitialized) return
        favorites.removeAllViews()
        prefs.getStringSet("favorites",emptySet())!!.toList().reversed().take(12).forEach{ addColorRow(it) }
    }

    private fun addColorRow(hex:String){
        val row=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
        }
        val swatch=View(this).apply{setBackgroundColor(Color.parseColor(hex))}
        row.addView(swatch,LinearLayout.LayoutParams(55,42).apply{rightMargin=12})
        val text=TextView(this).apply{text=hex;textSize=18f}
        row.addView(text,LinearLayout.LayoutParams(0,42,1f))
        val use=Button(this).apply{text="השתמש";setOnClickListener{setHex(hex)}}
        val cp=Button(this).apply{text="העתק";setOnClickListener{copy(hex)}}
        row.addView(use); row.addView(cp)
        favorites.addView(row)
    }

    private fun setHex(hex:String){
        val c=Color.parseColor(hex)
        bars[0].progress=Color.red(c); bars[1].progress=Color.green(c); bars[2].progress=Color.blue(c)
        update()
    }
}